// Life.cpp : Defines the entry point for the console application.
//

#include <conio.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#pragma warning(disable: 4996) 

#define FALSE	0
#define TRUE	1

#define DEP		10
#define	ROW		60
#define	COL		100

#define DEAD	'.'
#define DEAD2	','
#define	LIVE	'*'
#define	LIVE2	'#'
#define	LIVE3	'@'

#define TEST_SET "1234567890qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM,.;;''!@#$%^&*() _-+=<>?"

struct Life {
	char name[70];
	int	 gen;		// generation or Z 
	int	 row;		// Y 
	int	 col;		// X 
	int  version;
	int  active;
}; 

//typedef struct Life; 


int in(char ch, char* string)
{
	while (*string)
		if (ch == *string++)
			return TRUE;
	return FALSE;
}


int read_data(FILE *fp, char arr[][ROW][COL], int idx, Life *life)
{
	int		result;
	//	int		gen;		// Z
	//	int		row;		// Y
	//	int		col;		// X
	int		i, j;
	char	line[260];
	int		row_found = 0;
	int		col_found = 0;
	char	*pdest;

	int		number;
	//	int		string; 

		//puts("Reading in data..."); 
	do {
		fgets(line, 260, fp);
		//puts(line); 
		pdest = strchr(line, ':');
		pdest[strlen(pdest) - 1] = '\0';
		//puts(pdest);
		result = sscanf(pdest + 1, "%d", &number);

		if (strncmp(strupr(line), "ROW", 3) == 0)
		{
			//puts("found row"); 
			life->row = number;
			row_found = TRUE;
		}
		if (strncmp(strupr(line), "COL", 3) == 0)
		{
			//puts("found col");
			life->col = number;
			col_found = TRUE;
		}
		if (strncmp(strupr(line), "NAME", 4) == 0)
		{
			strcpy(life->name, pdest + 1);
			//puts("found name");

		}
		if (strncmp(strupr(line), "VER", 3) == 0)
		{
			life->version = number;
			//puts("found name");
		}

		//printf("Name: %s, row: %d, col: %d, version: %d \n", 
		//	life->name, life->row, life->col, life->version);
		//getchar(); 
	} while (!(row_found && col_found));


	// this loop populates the 2D plane 
	for (i = 0; i < life->row; i++)
	{

		fgets(line, 260, fp);
		//puts(line); 
		for (j = 0; j < life->col; j++) {
			if (j < (int)(strlen(line) - 1))
				if (in(line[j], TEST_SET))
					arr[idx][i][j] = line[j];
				else
					arr[idx][i][j] = DEAD;
			else
				arr[idx][i][j] = DEAD;
		}
		line[0] = '\0';
		if (idx >= 5)
			arr[idx][i][j + 1] = '\0';
		//getchar();
	}

	//printf("finished with file; hit <Enter> to continue...\n");
	//getchar();
	return 1; 
}

void display_slow(char arr[][ROW][COL], int idx, Life *life)
{
	int i, j;
	for (i = 0; i < life->row; i++)
	{
		for (j = 0; j < life->col; j++)
			printf("%c", arr[idx][i][j]);
		puts("");
	}
}

void display_fast(char arr[][ROW][COL], int idx, Life *life)
{

}

void show_data(char arr[][ROW][COL], int idx, Life *life)
{
	//int i, j; 
	//char choice; 
	//puts("Showing data, hit enter to continue"); 
	//getchar(); 
	//do {
		printf("Name: %s \n", life->name);
		puts("\n");
		//system("cls"); 
		display_slow(&arr[0], idx, life);

		/*
		do {
			printf("Hit 'P' for previous, 'N' for next, 'C' to continue");
			choice = getche(); 

		} while (!in(choice, "pPnNcC")); 
		*/

		puts("\nDone, hit <Enter> to copntinue...."); 

	//} while (!in(choice, "cC")); 

}

int	play_life(char arr[][ROW][COL], int idx, Life *life)
{
	puts("\nLife is not implemented yet, hit <Enter> to continue...");
	getchar();
	return FALSE; 
}


void save_data(FILE *fp, char arr[][ROW][COL])
{
	puts("Save_data is not implemented yet");
	puts("Hit <Enter> to continue...");
	getchar(); 
}



int main()
{
	char world[DEP][ROW][COL];
	Life lstat[DEP]; 

	//int  i, j;
	int	 cont, idx, result; 
	FILE *fp;
	//char buff[10];
	char fname[50] = "D:\\Life_0_.txt";   		// change this to reflect your location!!
	//char *cptr;

	Life life;


	for (idx = 0; idx < 6; idx++)
	{
		life.gen = idx;

		//cptr = strcat(fname, "D:\\Life");
		//cptr = itoa(idx, buff, 10);
		//cptr = strcat(fname, buff);
		//cptr = strcat(fname, ".txt");

		fname[9] = idx + '0';					// change this to reflect your filename!!
		printf("filename: %s \n", fname);
		//getchar();


		if ((fp = fopen(fname, "r")) == NULL)
		{
			printf("Couldn't open file %s, hit <Enter> to continue!", fname);
			getchar();
		}
		else
		{
			//printf("Calling read_data; hit <Enter> to continue..."); 
			//getchar(); 
			//puts("\n"); 
			result = read_data(fp, &world[life.gen], life.gen, &life);
			fclose(fp); 
			lstat[life.gen].active = 1; 

			do {
				show_data(&world[life.gen], life.gen, &life);
				cont = play_life(&world[life.gen], life.gen, &life);
			} while (cont); 

			printf("Finished with gen: %d, hit <Enter> to continue ", life.gen);
			getchar();
			puts("\n");
		}
	}

	return EXIT_SUCCESS; 
}
